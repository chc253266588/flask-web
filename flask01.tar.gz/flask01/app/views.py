from app import app
from flask import render_template,flash,url_for,redirect,session
from .forms import LoginForm
from .models import User,Role
from app import db

@app.route('/login',methods=['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user is None:
            user = User(username = form.username.data)
            db.session.add(user)
            db.session.commit()
            flash(form.username.data + ' successful! welcome!')
            session['known'] = False
        else:
        	session['known'] = True
        session['name'] = form.username.data
        #flash('Login requested for username:' + form.username.data)
        return redirect(url_for('index'))
    return render_template('login.html',form=form)
@app.route('/')
def index():
    name = session.get('name')
    return render_template('index.html',name=name,known=session.get('known'))